package com.csg.student.service;

import com.csg.student.modal.Student;
import com.csg.student.modal.User;
import com.csg.student.repository.StudentRepository;
import com.csg.student.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository studentRepository;
    
    @Autowired
    JdbcTemplate jdbcTemplate;

	//It will be provided on WebSecurityConfig as @Bean
    @Autowired
    private PasswordEncoder passwordEncoder;


    @Override
   public Student saveStudent(Student student){
        return studentRepository.save(student);
    }

    //save = create or update
    @Override
    public Student updateStudent(Student student){
		System.out.println("result  = "+findByUsername(student));

        return studentRepository.save(student);
    }

    @Override
    public void deleteStudent(Student student){
    	studentRepository.delete(student);
    }

    @Override
    public List<Student> findAllStudent(){
        return studentRepository.findAll();
    }
    
    @Override
	public List<Student> endOfDay() {
		// TODO Auto-generated method stub
    	LocalDate myObj = LocalDate.now();
    	
    	String sql = "select * from student where date = ?";
		List<Student> result = jdbcTemplate.query(sql, new Object[] {
				new java.util.Date()
        }, (rs, rowNum) -> {
			Student student = convert(rs);
            return student;
        });
		System.out.println("result  = "+result);
		
		return result;
	}
    
    static Student convert(ResultSet rs) throws SQLException {
    	Student student = new Student();
    	student.setId(rs.getInt("id"));
    	student.setClassName(rs.getString("className"));
    	student.setStudentName(rs.getString("studentName"));
    	student.setGrade(rs.getString("grade"));
    	student.setDate(rs.getDate("date").toLocalDate());
    	student.setTime(rs.getDate("time").toLocalDate());
    	student.setAttandance(rs.getBoolean("attendance"));
    	
        return student;
    }
    @Override
	public List<Student> endOfTerm() {
		// TODO Auto-generated method stub
		LocalDate date1 = LocalDate.now();
		//date1.minusMonths(4)
		
		String sql = "select * from student where date = ?";
		List<Student> result = jdbcTemplate.query(sql, new Object[] {
				date1.minusMonths(4)
        }, (rs, rowNum) -> {
			Student student = convert(rs);
            return student;
        });
		return result;
	}
    @Override
	public List<Student> findByUsername(Student student) {
		// TODO Auto-generated method stub
		List<Student> result = jdbcTemplate.query("select * from student where studentname = ?", new Object[] {
				 student.getStudentName()
		        },
		        new BeanPropertyRowMapper <Student> (Student.class));
		
		
		return result;
	}

}
