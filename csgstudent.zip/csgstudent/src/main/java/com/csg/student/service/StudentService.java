package com.csg.student.service;

import java.util.List;

import com.csg.student.modal.Student;
import com.csg.student.modal.User;

public interface StudentService {
	
	   public Student saveStudent(Student student);

	    public Student updateStudent(Student student);

	    public void deleteStudent(Student student);

	    public List<Student> findAllStudent();
	    
	    public List<Student> findByUsername(Student student);
		
	    List<Student> endOfDay();
	    
	    public List<Student> endOfTerm();

}
