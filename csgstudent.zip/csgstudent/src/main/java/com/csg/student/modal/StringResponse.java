package com.csg.student.modal;



public class StringResponse {
    private String response;
}
