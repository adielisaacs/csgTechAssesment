package com.csg.student.modal;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="student")
public class Student {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name="classname")
	private String className;

	@Column(name="studentname")
	private String studentName;

	@Column(name="grade")
	private String grade;

	@Column(name="date")
	private LocalDate date;

	@Column(name="time")
	private LocalDate time;
	
	@Column(name="attendance")
	private boolean attandance;
	
	
		public int getId() {
			return id;
		}

		

		public void setId(int id) {
			this.id = id;
		}

		public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}

		public String getStudentName() {
			return studentName;
		}

		public void setStudentName(String studentName) {
			this.studentName = studentName;
		}

		public String getGrade() {
			return grade;
		}

		public void setGrade(String grade) {
			this.grade = grade;
		}

		public LocalDate getDate() {
			return date;
		}

		public void setDate(LocalDate localDate) {
			this.date = localDate;
		}

		public LocalDate getTime() {
			return time;
		}

		public void setTime(LocalDate localDate) {
			this.time = localDate;
		}

		public boolean isAttandance() {
			return attandance;
		}

		public void setAttandance(boolean attandance) {
			this.attandance = attandance;
		}
		
}
