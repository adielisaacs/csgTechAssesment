package com.csg.student.modal;

public enum Role {
    USER
}


