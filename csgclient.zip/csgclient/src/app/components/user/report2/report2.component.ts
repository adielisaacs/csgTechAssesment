import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import {UserService} from "../../../services/user.service";
import {User} from "../../../model/user";
import {Student} from "../../../model/student";
import {MatPaginator} from "@angular/material/paginator";
import {MatTableDataSource} from "@angular/material/table";
import {MatSort} from "@angular/material/sort";
import {Router} from "@angular/router";
import {Observable} from "rxjs";

declare var $: any;

@Component({
  selector: 'app-detail2',
  templateUrl: './report2.component.html',
  styleUrls: ['./report2.component.css']
})
export class Report2Component implements OnInit {
 @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  studentList: Array<Student>;
  dataSource: MatTableDataSource<Student> = new MatTableDataSource();
  obs: Observable<any>;
  errorMessage: string;
  infoMessage: string;
  currentStudent: Student;
  display = "none";
  displayedColumns: string[] = ['className', 'studentName', 'grade', 'date'];

 constructor(private userService: UserService, private router: Router,
  private cdr: ChangeDetectorRef) {
    this.currentStudent = JSON.parse(localStorage.getItem("currentStudent"));
  }

  ngOnInit() {
    this.endOfTerm();
    this.obs = this.dataSource.connect();
  }

  ngAfterViewInit(){
    this.dataSource.paginator = this.paginator;
    this.cdr.detectChanges();
  }

  ngOnDestroy(): void {
    if(this.dataSource){
      this.dataSource.disconnect();
    }
  }
selectedRow(row) {
    console.log('selectedRow', row);
this.currentStudent = row;
  }
  endOfTerm(){
    this.userService.endOfTerm().subscribe(data => {
      this.studentList = data;
      this.dataSource.data = data;
	  this.currentStudent = this.studentList[0];
    });
  }
 

}
