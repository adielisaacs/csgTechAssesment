import { Component, OnInit } from '@angular/core';
import {UserService} from "../../../services/user.service";
import {Student} from "../../../model/student";
import {Router} from "@angular/router";

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  selectedStudent: Student = new Student();
  errorMessage: string;
  infoMessage: string;

  constructor(private userService: UserService, private router: Router) {
    this.selectedStudent = JSON.parse(localStorage.getItem('selectedStudent'));
   }

  ngOnInit() {
	this.selectedStudent = new Student();
  }

  logOut(){
    this.userService.logOut().subscribe(data => {
      this.router.navigate(['/login']);
    });
  }
  createStudent(){
	console.log(" class name"+this.selectedStudent.className);
	this.selectedStudent.date = new Date();
	this.selectedStudent.time = new Date();
    this.userService.addStudent(this.selectedStudent).subscribe(data => {
      this.infoMessage = "Mission is completed";

    },err => {
      this.errorMessage = "Unexpected error occurred.";
    });
	this.selectedStudent = new Student();

  }
}
