import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import {UserService} from "../../../services/user.service";
import {User} from "../../../model/user";
import {Student} from "../../../model/student";
import {MatPaginator} from "@angular/material/paginator";
import {MatTableDataSource} from "@angular/material/table";
import {MatSort} from "@angular/material/sort";
import {Router} from "@angular/router";
import {Observable} from "rxjs";

declare var $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  studentList: Array<Student>;
  dataSource: MatTableDataSource<Student> = new MatTableDataSource();
  obs: Observable<any>;
  errorMessage: string;
  infoMessage: string;
  currentStudent: Student;
  display = "none";
  displayedColumns: string[] = ['className', 'studentName', 'grade', 'date'];

  constructor(private userService: UserService, private router: Router,
  private cdr: ChangeDetectorRef) {
    this.currentStudent = JSON.parse(localStorage.getItem("currentStudent"));
  }

  ngOnInit() {
    this.findAllStudents();
    this.obs = this.dataSource.connect();
  }

  ngAfterViewInit(){
    this.dataSource.paginator = this.paginator;
    this.cdr.detectChanges();
  }

  ngOnDestroy(): void {
    if(this.dataSource){
      this.dataSource.disconnect();
    }
  }
selectedRow(row) {
    console.log('selectedRow', row);
this.currentStudent = row;
  }
  findAllStudents(){
    this.userService.findAllStudents().subscribe(data => {
      this.studentList = data;
      this.dataSource.data = data;
	  this.currentStudent = this.studentList[0];
    });
  }


 


  editStudent(){
    this.userService.updateStudent(this.currentStudent).subscribe(data => {
      let itemIndex = this.studentList.findIndex(item => item.id == this.currentStudent.id);
      this.studentList[itemIndex] = this.currentStudent;
      this.dataSource = new MatTableDataSource(this.studentList);
      this.infoMessage = "Mission is completed.";
    },err => {
      if(err.status === 409){
        this.errorMessage = "Username should be unique for each user.";
      }else{
        this.errorMessage = "Unexpected error occurred.";
      }
    });
  }

  deleteStudent(){
	    console.log('Delete Row >>> ');

    this.userService.deleteStudent(this.currentStudent).subscribe(data => {
      let itemIndex = this.studentList.findIndex(item => item.id == this.currentStudent.id);
      if(itemIndex !== -1){
        this.studentList.splice(itemIndex, 1);
      }
      this.dataSource = new MatTableDataSource(this.studentList);
      this.infoMessage = "Student "+this.currentStudent.studentName+" deletion is completed.";
    },err => {
      this.errorMessage = "Unexpected error occurred.";
    });
  }

}
