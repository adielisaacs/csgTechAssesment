import {User} from './user';
export class Student {
 
	 id: number;
	 className:String ="" ;
	 studentName:String ="";
	 grade:String="";
	 date:any;
	 time:any;
	 attandance:any;
}
